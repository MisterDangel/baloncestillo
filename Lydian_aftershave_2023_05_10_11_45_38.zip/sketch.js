
let width = 400
let height = 400

function setup(){
    createCanvas(width,height);
  background("cyan");
  
  
}

function draw(){
rect(width-5, )
}